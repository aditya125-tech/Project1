<div class="col-sm-12">
<p class="color-gray" align="center"> Expense Tracker Powered by @ Aditya Tiwari</p>
			</div>